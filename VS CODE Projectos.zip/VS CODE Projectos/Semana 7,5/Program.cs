﻿using System;

class SimuladorCajero
{
    static void Main()
    {
        Console.Write("Ingrese el monto: ");
        int monto = int.Parse(Console.ReadLine());

        int[] denominaciones = { 2000, 1000, 500, 200, 100, 50, 25, 10, 5, 1 };

        Console.WriteLine("Cantidad mínima de monedas y billetes:");
        foreach (int denominacion in denominaciones)
        {
            int cantidad = monto / denominacion;
            if (cantidad > 0)
            {
                Console.WriteLine("{0}: {1}", denominacion, cantidad);
                monto %= denominacion;
            }
        }
    }
}