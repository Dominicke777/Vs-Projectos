﻿Console.Write("Introducir número de suma 1: ");
int mas_1 = int.Parse(Console.ReadLine());

Console.Write("Introducir número de suma 2: ");
int mas_2 = int.Parse(Console.ReadLine());

Console.Write("Introducir número divisor: ");
int Divisor = int.Parse(Console.ReadLine());

double resultado = (mas_1 + mas_2) / (double)Divisor;

Console.WriteLine($"El resultado del cálculo es: {resultado}");
