﻿using System;

namespace HIPOTENUSA
{
    class Program
    {
        static void Main()
        {
            double cateto1, cateto2, hipotenusa;

            Console.WriteLine("Agrega el valor del primer cateto:");
            cateto1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Agrega el valor del segundo cateto:");
            cateto2 = Convert.ToDouble(Console.ReadLine());

            hipotenusa = Math.Sqrt((cateto1 * cateto1) + (cateto2 * cateto2));

            Console.WriteLine($"La hipotenusa de los catetos {cateto1} y {cateto2} es: {hipotenusa:F2}");
        }
    }
}