﻿using System;

class SueldoBruto
{
    static void Main()
    {
        Console.Write("Ingrese su sueldo bruto (RD$): ");
        double sueldoBruto = double.Parse(Console.ReadLine());

        double SFS = sueldoBruto * 0.0304;
        double AFP = sueldoBruto * 0.0287;
        double totalDeducciones = SFS + AFP;
        double baseImponible = sueldoBruto - totalDeducciones;
        double ingresoAnual = baseImponible * 12;
        double excedente = 0;
        double impuestoAnual = 0;

        if (ingresoAnual > 416220.01)
        {
            excedente = ingresoAnual - 416220.01;
            impuestoAnual = excedente * 0.15;
        }

        double impuestoMensual = impuestoAnual / 12;
        double sueldoNeto = baseImponible - impuestoMensual;

        Console.WriteLine($"SFS (3.04%): RD${SFS:F2}");
        Console.WriteLine($"AFP (2.87%): RD${AFP:F2}");
        Console.WriteLine($"Total Deducciones: RD${totalDeducciones:F2}");
        Console.WriteLine($"Base Imponible: RD${baseImponible:F2}");
        Console.WriteLine($"Ingreso Anual: RD${ingresoAnual:F2}");
        Console.WriteLine($"Excedente: RD${excedente:F2}");
        Console.WriteLine($"Impuesto Anual: RD${impuestoAnual:F2}");
        Console.WriteLine($"Impuesto Mensual: RD${impuestoMensual:F2}");
        Console.WriteLine($"Sueldo Neto: RD${sueldoNeto:F2}");
    }
}
