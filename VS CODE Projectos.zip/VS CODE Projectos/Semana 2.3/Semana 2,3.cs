﻿Console.Write("¿Cómo se llama? ");
string Nombre = Console.ReadLine();
Console.WriteLine($"Hola, {Nombre}");
