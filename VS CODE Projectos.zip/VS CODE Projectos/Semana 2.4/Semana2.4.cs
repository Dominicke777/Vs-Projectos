﻿Console.Write("Introducir primer número: ");
int mas1 = int.Parse(Console.ReadLine());

Console.Write("Introducir segundo número: ");
int mas2 = int.Parse(Console.ReadLine());

int x = mas1 * mas2;

Console.WriteLine($"La multiplicación de {mas1} y {mas2} es {x}");
