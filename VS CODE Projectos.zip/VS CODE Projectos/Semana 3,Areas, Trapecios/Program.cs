﻿using System;

namespace Areas
{
    class Program
    {
        static void Main()
        {
            double  base1, base2, altura, area;


            Console.WriteLine("Agrega el valor de la primera base del trapecio:");
            base1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Agrega el valor de la segunda base del trapecio:");
            base2 = Convert.ToDouble(Console.ReadLine());

             Console.WriteLine("Agrega el valor de la altura del trapecio:");
            altura = Convert.ToDouble(Console.ReadLine());


            area = (base1 + base2) * altura/2;

            Console.WriteLine($"El área del trapecio sobre la primera base {base1}, sumado a la segunda base {base2} multiplicado por la altura {altura} entre dos es: {area}");
        }
    }
}
