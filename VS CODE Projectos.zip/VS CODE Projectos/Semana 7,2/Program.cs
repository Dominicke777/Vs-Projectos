﻿
using System;

class ParImpar
{
    static void Main()
    {
        Console.Write("Ingrese un número: ");
        int numero = int.Parse(Console.ReadLine());

        if (numero % 2 == 0)
            Console.WriteLine("El número {0} es par.", numero);
        else
            Console.WriteLine("El número {0} es impar.", numero);
    }
}