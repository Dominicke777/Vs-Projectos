﻿using System;

class NumeroPrimo
{
    static void Main()
    {
        Console.Write("Ingrese un número: ");
        int numero = int.Parse(Console.ReadLine());

        if (EsPrimo(numero))
            Console.WriteLine("El número {0} es primo.", numero);
        else
            Console.WriteLine("El número {0} no es primo.", numero);
    }

    static bool EsPrimo(int numero)
    {
        if (numero <= 1)
            return false;

        for (int i = 2; i < numero; i++)
        {
            if (numero % i == 0)
                return false;
        }

        return true;
    }
}