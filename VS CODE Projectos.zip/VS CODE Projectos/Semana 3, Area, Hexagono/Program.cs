﻿using System;

namespace Areas
{
    class Program
    {
        static void Main()
        {
            double  perimetro, apotema, area;


            Console.WriteLine("Agrega el valor del perimetro del perimetro:");
            perimetro = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Agrega el valor del apotema del apotema:");
            apotema = Convert.ToDouble(Console.ReadLine());

    


            area = perimetro* apotema/2;

            Console.WriteLine($"El área del hexagono sobre el perimetro {perimetro} multiplicado por el apotema {apotema} entre 2 es {area}");
        }
    }
}
