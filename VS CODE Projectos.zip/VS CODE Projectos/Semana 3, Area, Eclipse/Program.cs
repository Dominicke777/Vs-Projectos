﻿using System;

namespace Areas
{
    class Program
    {
        static void Main()
        {
            double  eje_mayor, eje_menor, area;


            Console.WriteLine("Agrega el valor del eje menor:");
            eje_menor = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Agrega el valor del eje mayor:");
            eje_mayor = Convert.ToDouble(Console.ReadLine());

if (eje_mayor < eje_menor)
{
    Console.WriteLine("el eje menor no puede ser mas grande que el menor");
    return;
}
            area = eje_mayor*eje_menor*3.14;

            Console.WriteLine($"El área del eclipse sobre el eje menor {eje_menor} por el eje mayor{eje_mayor} por PI es {area}");
        }
    }
}
