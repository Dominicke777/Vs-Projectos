﻿using System;

class Fibonacci
{
    static void Main()
    {
        Console.Write("Ingrese la cantidad de elementos de la secuencia Fibonacci: ");
        int n = int.Parse(Console.ReadLine());

        int a = 0, b = 1, c;
        Console.Write("Los numeros que desencadenan la secuencia fibonacci son: {0} {1} ", a, b);

        for (int i = 2; i < n; i++)
        {
            c = a + b;
            Console.Write("{0} ", c);
            a = b;
            b = c;
        }
    }
}