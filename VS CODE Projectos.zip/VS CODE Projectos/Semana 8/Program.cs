﻿using System;

class Calculadora
{
    private double AreaCuadrado(double lado)
    {
        return lado * lado;
    }

    private double AreaRectangulo(double baseRect, double altura)
    {
        return baseRect * altura;
    }

    private double AreaTriangulo(double baseTri, double altura)
    {
        return (baseTri * altura) / 2;
    }

    private double AreaCirculo(double radio)
    {
        return Math.PI * radio * radio;
    }

    private double AreaCono(double radio, double generatriz)
    {
        return Math.PI * radio * generatriz;
    }

    private double Hipotenusa(double cateto1, double cateto2)
    {
        return Math.Sqrt((cateto1 * cateto1) + (cateto2 * cateto2));
    }

    
    private void Menu()
    {
        while (true)
        {
            Console.Clear();

            Console.WriteLine("----------------Calculadora de Areas---------------");
            Console.WriteLine("1. Área del cuadrado");
            Console.WriteLine("2. Área del rectángulo");
            Console.WriteLine("3. Área del triángulo");
            Console.WriteLine("4. Área del círculo");
            Console.WriteLine("5. Área del cono");
            Console.WriteLine("6. Hipotenusa (Teorema de Pitágoras)");
    

            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    Console.Write("Ingrese el lado del cuadrado: ");
                    double lado = double.Parse(Console.ReadLine());
                    double areaCuadrado = AreaCuadrado(lado);
                    Console.WriteLine($"El área del cuadrado es: {areaCuadrado:F2}");
                    break;

                case "2":
                    Console.Write("Ingrese la base del rectángulo: ");
                    double baseRect = double.Parse(Console.ReadLine());
                    Console.Write("Ingrese la altura del rectángulo: ");
                    double alturaRect = double.Parse(Console.ReadLine());
                    double areaRect = AreaRectangulo(baseRect, alturaRect);
                    Console.WriteLine($"El área del rectángulo es: {areaRect:F2}");
                    break;

                case "3":
                    Console.Write("Ingrese la base del triángulo: ");
                    double baseTri = double.Parse(Console.ReadLine());
                    Console.Write("Ingrese la altura del triángulo: ");
                    double alturaTri = double.Parse(Console.ReadLine());
                    double areaTri = AreaTriangulo(baseTri, alturaTri);
                    Console.WriteLine($"El área del triángulo es: {areaTri:F2}");
                    break;

                case "4":
                    Console.Write("Ingrese el radio del círculo: ");
                    double radioCirculo = double.Parse(Console.ReadLine());
                    double areaCirculo = AreaCirculo(radioCirculo);
                    Console.WriteLine($"El área del círculo es: {areaCirculo:F2}");
                    break;

                case "5":
                    Console.Write("Ingrese el radio del cono: ");
                    double radioCono = double.Parse(Console.ReadLine());
                    Console.Write("Ingrese la generatriz del cono: ");
                    double generatriz = double.Parse(Console.ReadLine());
                    double areaCono = AreaCono(radioCono, generatriz);
                    Console.WriteLine($"El área del cono es: {areaCono:F2}");
                    break;

                case "6":
                    Console.Write("Ingrese el primer cateto: ");
                    double cateto1 = double.Parse(Console.ReadLine());
                    Console.Write("Ingrese el segundo cateto: ");
                    double cateto2 = double.Parse(Console.ReadLine());
                    double hipotenusa = Hipotenusa(cateto1, cateto2);
                    Console.WriteLine($"La hipotenusa es: {hipotenusa:F2}");
                    break;

                default:
                    Console.WriteLine("Opción no válida. Intente de nuevo.");
                    break;
            }
        }
    }
    static void Main(string[] args)
    {
        Calculadora calculadora = new Calculadora();
        calculadora.Menu();
    }
}