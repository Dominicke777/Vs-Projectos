﻿using System;
using System.Security;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Por favor, ingresa tu edad: ");
        int edad = int.Parse(Console.ReadLine());

        if (edad < 18)
        {
            Console.WriteLine("Eres menor, ponte a ver muñequitos.");
        }
        else if (edad >= 18)
        {
            Console.WriteLine("Puedes tributar, ingresa tus ingresos mensuales: ");
            double ingresos = double.Parse(Console.ReadLine());

            if (ingresos > 15000)
            {
                Console.WriteLine("¡Felicidades!");
            }
        }
    }
}
