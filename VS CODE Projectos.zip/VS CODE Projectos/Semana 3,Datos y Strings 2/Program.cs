﻿class Program
{
    static void Main(string[] args)
    {
        Console.Write("Ingresar primera fecha: ");
        DateTime fecha1 = DateTime.Parse(Console.ReadLine());

        Console.Write("Ingresar segunda fecha: ");
        DateTime fecha2 = DateTime.Parse(Console.ReadLine());

        Console.WriteLine($"Días transcurridos -> Fecha1: {fecha1.DayOfYear}, Fecha2: {fecha2.DayOfYear}");
        Console.WriteLine($"Diferencia en dias: {(fecha2 - fecha1).Days}");
        Console.WriteLine($"Dia numerico de Fecha1: {fecha1.Day}, Día de la semana de Fecha2: {fecha2.DayOfWeek}");
        Console.WriteLine($"Fecha2 + dias de Fecha1: {fecha2.AddDays(fecha1.DayOfYear):yyyy-MM-dd}");
        Console.WriteLine($"Fecha1 + años de Fecha2: {fecha1.AddYears(fecha2.Year):yyyy-MM-dd}");
    }
}