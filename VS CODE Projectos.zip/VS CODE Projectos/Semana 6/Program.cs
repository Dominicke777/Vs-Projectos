﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Seleccione el subprograma que desea correr (1-4):");
        Console.WriteLine("1. Mostrar números descendentes del 100 al 1 de dos en dos");
        Console.WriteLine("2. Mostrar la tabla del número ingresado desde 10 hasta 100");
        Console.WriteLine("3. Calcular la suma y el promedio de una cantidad de montos");
        Console.WriteLine("4. Pedir nombres hasta que sea 'Jose' o 'José', con un límite de 8 nombres");
        Console.Write("Seleccione una opción: ");
        int opcion = int.Parse(Console.ReadLine());

        Console.WriteLine("\nSeleccione el tipo de bucle a utilizar:");
        Console.WriteLine("1. While");
        Console.WriteLine("2. Do/While");
        Console.WriteLine("3. For");
        Console.Write("Seleccione una opción: ");
        int tipoBucle = int.Parse(Console.ReadLine());

        switch (opcion)
        {
            case 1:
                MostrarDescendentes(tipoBucle);
                break;
            case 2:
                TablaMultiplicar(tipoBucle);
                break;
            case 3:
                CalcularSumaPromedio(tipoBucle);
                break;
            case 4:
                PedirNombres(tipoBucle);
                break;
            default:
                Console.WriteLine("Opción no válida.");
                break;
        }
    }

    static void MostrarDescendentes(int tipoBucle)
    {
        Console.WriteLine("\nMostrando números descendentes del 100 al 1 de dos en dos:");

        if (tipoBucle == 1) // While
        {
            int i = 100;
            while (i >= 1)
            {
                Console.WriteLine(i);
                i -= 2;
            }
        }
        else if (tipoBucle == 2) // Do/While
        {
            int i = 100;
            do
            {
                Console.WriteLine(i);
                i -= 2;
            } while (i >= 1);
        }
        else if (tipoBucle == 3) // For
        {
            for (int i = 100; i >= 1; i -= 2)
            {
                Console.WriteLine(i);
            }
        }
    }

    static void TablaMultiplicar(int tipoBucle)
    {
        Console.Write("\nIngrese un número: ");
        int numero = int.Parse(Console.ReadLine());
        Console.WriteLine($"\nTabla del {numero} desde 10 hasta 100:");

        if (tipoBucle == 1) // While
        {
            int i = 10;
            while (i <= 100)
            {
                Console.WriteLine($"{numero} x {i} = {numero * i}");
                i += 10;
            }
        }
        else if (tipoBucle == 2) // Do/While
        {
            int i = 10;
            do
            {
                Console.WriteLine($"{numero} x {i} = {numero * i}");
                i += 10;
            } while (i <= 100);
        }
        else if (tipoBucle == 3) // For
        {
            for (int i = 10; i <= 100; i += 10)
            {
                Console.WriteLine($"{numero} x {i} = {numero * i}");
            }
        }
    }

    static void CalcularSumaPromedio(int tipoBucle)
    {
        Console.Write("\nIngrese la cantidad de montos: ");
        int cantidad = int.Parse(Console.ReadLine());
        double suma = 0;

        if (tipoBucle == 1) // While
        {
            int i = 1;
            while (i <= cantidad)
            {
                Console.Write($"Monto {i}: ");
                suma += double.Parse(Console.ReadLine());
                i++;
            }
        }
        else if (tipoBucle == 2) // Do/While
        {
            int i = 1;
            do
            {
                Console.Write($"Monto {i}: ");
                suma += double.Parse(Console.ReadLine());
                i++;
            } while (i <= cantidad);
        }
        else if (tipoBucle == 3) // For
        {
            for (int i = 1; i <= cantidad; i++)
            {
                Console.Write($"Monto {i}: ");
                suma += double.Parse(Console.ReadLine());
            }
        }

        double promedio = suma / cantidad;
        Console.WriteLine($"\nLa suma total es: {suma}");
        Console.WriteLine($"El promedio es: {promedio}");
    }

    static void PedirNombres(int tipoBucle)
    {
        Console.WriteLine("\nIngrese nombres. El programa terminará cuando escriba 'Jose' o 'José', o si ha ingresado 8 nombres.");
        int contador = 0;
        bool encontrado = false;

        if (tipoBucle == 1) // While
        {
            while (contador < 8 && !encontrado)
            {
                Console.Write("Ingrese un nombre: ");
                string nombre = Console.ReadLine();
                contador++;
                if (nombre.Equals("Jose", StringComparison.OrdinalIgnoreCase) || nombre.Equals("José", StringComparison.OrdinalIgnoreCase))
                {
                    encontrado = true;
                }
            }
        }
        else if (tipoBucle == 2) // Do/While
        {
            do
            {
                Console.Write("Ingrese un nombre: ");
                string nombre = Console.ReadLine();
                contador++;
                if (nombre.Equals("Jose", StringComparison.OrdinalIgnoreCase) || nombre.Equals("José", StringComparison.OrdinalIgnoreCase))
                {
                    encontrado = true;
                }
            } while (contador < 8 && !encontrado);
        }
        else if (tipoBucle == 3) // For
        {
            for (int i = 0; i < 8 && !encontrado; i++)
            {
                Console.Write("Ingrese un nombre: ");
                string nombre = Console.ReadLine();
                if (nombre.Equals("Jose", StringComparison.OrdinalIgnoreCase) || nombre.Equals("José", StringComparison.OrdinalIgnoreCase))
                {
                    encontrado = true;
                }
            }
        }

        if (encontrado)
        {
            Console.WriteLine("Se encontró el nombre 'Jose' o 'José'.");
        }
        else
        {
            Console.WriteLine("No se encontró el nombre 'Jose' o 'José' después de 8 intentos.");
        }
    }
}
