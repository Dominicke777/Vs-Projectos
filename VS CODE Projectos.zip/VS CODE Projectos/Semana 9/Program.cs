﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.Write("Ingrese la cantidad de empleados: ");
        int cantidadEmpleados = int.Parse(Console.ReadLine());

        // Declarar colecciones para almacenar datos de empleados
        List<string> nombres = new List<string>();
        List<string> apellidos = new List<string>();
        List<double> salariosBrutos = new List<double>();

        // Arreglos para deducciones
        double[] afps = new double[cantidadEmpleados];
        double[] sss = new double[cantidadEmpleados];
        double[] isrs = new double[cantidadEmpleados];

        // Acumuladores para totales generales
        double totalSalariosBrutos = 0, totalAFP = 0, totalSS = 0, totalISR = 0, totalNeto = 0;

        // Ingresar datos de los empleados
        for (int i = 0; i < cantidadEmpleados; i++)
        {
            Console.WriteLine($"\nEmpleado #{i + 1}:");
            Console.Write("Nombre: ");
            nombres.Add(Console.ReadLine());

            Console.Write("Apellido: ");
            apellidos.Add(Console.ReadLine());

            Console.Write("Salario Bruto: ");
            double salarioBruto = double.Parse(Console.ReadLine());
            salariosBrutos.Add(salarioBruto);

            // Calcular deducciones
            afps[i] = CalcularAFP(salarioBruto);
            sss[i] = CalcularSS(salarioBruto);
            isrs[i] = CalcularISR(salarioBruto);

            // Actualizar acumuladores
            totalSalariosBrutos += salarioBruto;
            totalAFP += afps[i];
            totalSS += sss[i];
            totalISR += isrs[i];
            totalNeto += salarioBruto - (afps[i] + sss[i] + isrs[i]);
        }

        // Mostrar reporte
        MostrarReporte(nombres, apellidos, salariosBrutos, afps, sss, isrs, totalSalariosBrutos, totalAFP, totalSS, totalISR, totalNeto);
    }

    // Función para calcular AFP
    static double CalcularAFP(double salario)
    {
        return salario * 0.0287; // Ejemplo: 2.87% del salario
    }

    // Función para calcular SS
    static double CalcularSS(double salario)
    {
        return salario * 0.0304; // Ejemplo: 3.04% del salario
    }

    // Función para calcular ISR
    static double CalcularISR(double salario)
    {
        if (salario <= 34685) return 0;
        else if (salario <= 52027) return (salario - 34685) * 0.15;
        else return (salario - 52027) * 0.25 + 2601.33;
    }

    // Procedimiento para mostrar el reporte
    static void MostrarReporte(
        List<string> nombres,
        List<string> apellidos,
        List<double> salariosBrutos,
        double[] afps,
        double[] sss,
        double[] isrs,
        double totalSalariosBrutos,
        double totalAFP,
        double totalSS,
        double totalISR,
        double totalNeto)
    {
        Console.WriteLine("\n--- REPORTE DE DEDUCCIONES ---");
        Console.WriteLine("-----------------------------------------------------------------");
        Console.WriteLine("Nombre\t\tApellido\tSalario Bruto\tAFP\tSS\tISR\tNeto");
        Console.WriteLine("-----------------------------------------------------------------");

        for (int i = 0; i < nombres.Count; i++)
        {
            double salarioNeto = salariosBrutos[i] - (afps[i] + sss[i] + isrs[i]);
            Console.WriteLine($"{nombres[i]}\t\t{apellidos[i]}\t\t{salariosBrutos[i]:F2}\t\t{afps[i]:F2}\t{sss[i]:F2}\t{isrs[i]:F2}\t{salarioNeto:F2}");
        }

        Console.WriteLine("-----------------------------------------------------------------");
        Console.WriteLine($"Totales:\t\t\t{totalSalariosBrutos:F2}\t\t{totalAFP:F2}\t{totalSS:F2}\t{totalISR:F2}\t{totalNeto:F2}");
    }
}
