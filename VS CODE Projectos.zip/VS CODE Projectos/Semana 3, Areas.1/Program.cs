﻿

using System;

namespace Areas
{
    class Program
    {
        static void Main()
        {
            double lado, area;

            Console.WriteLine("Agrega el valor del lado del cuadrado:");
            lado = Convert.ToDouble(Console.ReadLine());

            area = lado * lado;

            Console.WriteLine($"El área del cuadrado con lado {lado} es: {area}");
        }
    }
}
