﻿using System;

class Bisiesto
{
    static void Main()
    {
        Console.Write("Ingrese el año a comparar: ");
        int year = Convert.ToInt32(Console.ReadLine());

        if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
        {
            Console.WriteLine($"El año {year} es bisiesto.");
        }
        else
        {
            Console.WriteLine($"El año {year} no es bisiesto.");
        }
    }
}
