﻿using System;

class Program
{
    static void Main(string[] args)
    {
        string primerNombre = "Dominic";
        string segundoNombre = "Hoenow";
        string primerApellido = "Jiminian";

        Console.WriteLine(primerNombre + " " + segundoNombre + " " + primerApellido);
    }
}
