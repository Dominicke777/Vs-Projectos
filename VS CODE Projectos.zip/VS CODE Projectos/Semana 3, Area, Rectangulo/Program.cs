﻿using System;

namespace Areas
{
    class Program
    {
        static void Main()
        {
            double largo = 0, ancho = 0, area;

            Console.WriteLine("Calculadora del área de un rectángulo\n");

            // Solicitar el valor del largo
            while (true)
            {
                Console.Write("Agrega el valor del largo del rectángulo: ");
                if (double.TryParse(Console.ReadLine(), out largo) && largo > 0)
                {
                    break;
                }
                Console.WriteLine("Por favor, introduce un número válido mayor que 0.");
            }

            // Solicitar el valor del ancho
            while (true)
            {
                Console.Write("Agrega el valor del ancho del rectángulo: ");
                if (double.TryParse(Console.ReadLine(), out ancho) && ancho > 0)
                {
                    break;
                }
                Console.WriteLine("Por favor, introduce un número válido mayor que 0.");
            }

            // Calcular el área
            area = largo * ancho;

            // Mostrar el resultado
            Console.WriteLine($"\nEl área del rectángulo con ancho {ancho} y largo {largo} es: {area}");
        }
    }
}
