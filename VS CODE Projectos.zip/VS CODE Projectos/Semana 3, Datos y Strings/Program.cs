﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Ingrese su nombre: ");
        string nombres = Console.ReadLine();
        Console.Write("Ingrese su/s apellidos: ");
        string apellidos = Console.ReadLine();

        string nombreCompleto = $"{nombres} {apellidos}";

        Console.WriteLine($"Longitud Nombre: {nombres.Length}, Apellido/s: {apellidos.Length}, Nombre Completo: {nombreCompleto.Length}");
        Console.WriteLine($"Nombre Completo: {nombreCompleto}");
        Console.WriteLine($"Nombre Completo (underscores): {nombreCompleto.Replace(" ", "_")}");
        Console.WriteLine($"Nombres en mayúscula: {nombres.ToUpper()}");
        Console.WriteLine($"Apellidos en minúscula: {apellidos.ToLower()}");
        Console.WriteLine($"Primer carácter del apellido: {apellidos[0]}");
        Console.WriteLine($"Último carácter del nombre: {nombres[^1]}");
    }
}
