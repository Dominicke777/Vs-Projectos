﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("¿Cuál es tu renta anual? ");
        
        // Validar entrada para evitar errores
        double renta;
        while (!double.TryParse(Console.ReadLine(), out renta) || renta < 0)
        {
            Console.Write("Por favor, ingresa un valor válido para tu renta anual: ");
        }

        string Impositivo = "";

        // Determinar el tipo impositivo basado en la renta
        if (renta < 100000)
        {
            Impositivo = "5%";
        }
        else if (renta >= 100000 && renta <= 200000)
        {
            Impositivo = "15%";
        }
        else if (renta > 200000 && renta <= 350000)
        {
            Impositivo = "20%";
        }
        else if (renta > 350000 && renta <= 600000)
        {
            Impositivo = "30%";
        }
        else if (renta > 600000)
        {
            Impositivo = "45%";
        }
        else
        {
            Impositivo = "Sin categoría"; // Caso por si algo inesperado ocurre
        }

        // Mostrar el resultado
        Console.WriteLine($"Tu renta anual es de {renta:N2} y por eso tienes un tipo impositivo del {Impositivo}.");
    }
}
