﻿Console.WriteLine("Introduce 5 números para calcular la suma y el promedio de los valores dados");
int mas = 0;

for (int i = 1; i <= 5; i++)
{
    Console.Write($"Número {i}: ");
    mas += int.Parse(Console.ReadLine());
}

double promedio = mas / 5.0;

Console.WriteLine($"La suma de los 5 números es: {mas}");
Console.WriteLine($"El promedio de los 5 números es: {promedio}");
