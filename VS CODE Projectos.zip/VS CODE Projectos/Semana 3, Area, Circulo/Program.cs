﻿using System;

namespace Areas
{
    class Program
    {
        static void Main()
        {
            double  radio, area;


            Console.WriteLine("Agrega el valor del radio del circulo:");
            radio = Convert.ToDouble(Console.ReadLine());

    


            area = (radio*radio)*3.14;

            Console.WriteLine($"El área del circulo sobre el radio {radio} al cuadrado multiplicado por PI es {area}");
        }
    }
}
