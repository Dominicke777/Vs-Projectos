﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Tabla del 12:");
        
        for (int i = 1; i <= 12; i++)
        {
            Console.WriteLine($"12 x {i} = {12 * i}");
        }
    }
}
