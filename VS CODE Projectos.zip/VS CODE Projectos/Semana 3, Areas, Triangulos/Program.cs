﻿using System;

namespace Areas
{
    class Program
    {
        static void Main()
        {
            double  area, altura, Base;


            Console.WriteLine("Agrega el valor de la base del triangulo:");
            Base = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Agrega el valor de la altura del triangulo:");
            altura = Convert.ToDouble(Console.ReadLine());


            area = altura * Base/2;

            Console.WriteLine($"El área del triangulo sobre la base {Base} y la altura {altura} entre dos es: {area}");
        }
    }
}
