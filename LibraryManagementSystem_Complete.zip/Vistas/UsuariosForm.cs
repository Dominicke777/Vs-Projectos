
using System;
using System.Windows.Forms;
using LibraryManagementSystem.Controladores;
using LibraryManagementSystem.Modelos;

namespace LibraryManagementSystem.Vistas
{
    public partial class UsuariosForm : Form
    {
        public UsuariosForm()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Usuario usuario = new Usuario
            {
                Nombre = txtNombre.Text,
                Apellido = txtApellido.Text,
                Email = txtEmail.Text,
                Telefono = txtTelefono.Text
            };

            // Llamar al controlador para agregar el usuario
            // UsuarioController.AgregarUsuario(usuario);
            MessageBox.Show("Usuario agregado exitosamente.");
        }
    }
}
