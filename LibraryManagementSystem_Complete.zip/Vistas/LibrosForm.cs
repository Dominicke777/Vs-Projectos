
using System;
using System.Windows.Forms;
using LibraryManagementSystem.Controladores;
using LibraryManagementSystem.Modelos;

namespace LibraryManagementSystem.Vistas
{
    public partial class LibrosForm : Form
    {
        public LibrosForm()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Libro libro = new Libro
            {
                ISBN = txtISBN.Text,
                Titulo = txtTitulo.Text,
                Autor = txtAutor.Text,
                Editorial = txtEditorial.Text,
                AnoPublicacion = int.Parse(txtAnoPublicacion.Text),
                Genero = txtGenero.Text,
                NumeroCopias = int.Parse(txtNumeroCopias.Text)
            };

            LibroController.AgregarLibro(libro);
            MessageBox.Show("Libro agregado exitosamente.");
        }
    }
}
