
using System;
using System.Windows.Forms;
using LibraryManagementSystem.Controladores;
using LibraryManagementSystem.Modelos;

namespace LibraryManagementSystem.Vistas
{
    public partial class ReservasForm : Form
    {
        public ReservasForm()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Reserva reserva = new Reserva
            {
                UsuarioID = int.Parse(txtUsuarioID.Text),
                LibroID = int.Parse(txtLibroID.Text),
                FechaReserva = dtpFechaReserva.Value,
                FechaRetorno = dtpFechaRetorno.Value
            };

            // Llamar al controlador para agregar la reserva
            // ReservaController.AgregarReserva(reserva);
            MessageBox.Show("Reserva agregada exitosamente.");
        }
    }
}
