
using System;

namespace LibraryManagementSystem.Modelos
{
    public class Reserva
    {
        public int ID { get; set; }
        public int UsuarioID { get; set; }
        public int LibroID { get; set; }
        public DateTime FechaReserva { get; set; }
        public DateTime FechaRetorno { get; set; }
    }
}
