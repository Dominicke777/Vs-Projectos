
using System;

namespace LibraryManagementSystem.Modelos
{
    public class Libro
    {
        public int ID { get; set; }
        public string ISBN { get; set; }
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public string Editorial { get; set; }
        public int AnoPublicacion { get; set; }
        public string Genero { get; set; }
        public int NumeroCopias { get; set; }
    }
}
