
using System;
using System.Data.SqlClient;

namespace LibraryManagementSystem.Controladores
{
    public static class DatabaseConnection
    {
        private static readonly string connectionString = "your_connection_string_here";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}
