
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using LibraryManagementSystem.Modelos;

namespace LibraryManagementSystem.Controladores
{
    public class LibroController
    {
        public static void AgregarLibro(Libro libro)
        {
            using (SqlConnection connection = DatabaseConnection.GetConnection())
            {
                string query = "INSERT INTO Libros (ISBN, Titulo, Autor, Editorial, AnoPublicacion, Genero, NumeroCopias) " +
                               "VALUES (@ISBN, @Titulo, @Autor, @Editorial, @AnoPublicacion, @Genero, @NumeroCopias)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ISBN", libro.ISBN);
                command.Parameters.AddWithValue("@Titulo", libro.Titulo);
                command.Parameters.AddWithValue("@Autor", libro.Autor);
                command.Parameters.AddWithValue("@Editorial", libro.Editorial);
                command.Parameters.AddWithValue("@AnoPublicacion", libro.AnoPublicacion);
                command.Parameters.AddWithValue("@Genero", libro.Genero);
                command.Parameters.AddWithValue("@NumeroCopias", libro.NumeroCopias);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }
        
        public static List<Libro> ObtenerLibros()
        {
            List<Libro> libros = new List<Libro>();
            using (SqlConnection connection = DatabaseConnection.GetConnection())
            {
                string query = "SELECT * FROM Libros";
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    libros.Add(new Libro
                    {
                        ID = (int)reader["ID"],
                        ISBN = reader["ISBN"].ToString(),
                        Titulo = reader["Titulo"].ToString(),
                        Autor = reader["Autor"].ToString(),
                        Editorial = reader["Editorial"].ToString(),
                        AnoPublicacion = (int)reader["AnoPublicacion"],
                        Genero = reader["Genero"].ToString(),
                        NumeroCopias = (int)reader["NumeroCopias"]
                    });
                }
            }
            return libros;
        }
    }
}
