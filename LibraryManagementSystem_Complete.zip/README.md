
# Library Management System

Este proyecto está diseñado para gestionar libros, usuarios y reservas en una biblioteca.

## Estructura del Proyecto

- **Modelos**: Contiene las clases de datos (Libros, Usuarios, Reservas).
- **Vistas**: Interfaces gráficas diseñadas en Windows Forms o WPF.
- **Controladores**: Manejo de la lógica de negocio y comunicación con la base de datos.

## Requerimientos
- Lenguaje: C#
- Entorno: Visual Studio 2019 o superior
- Base de Datos: SQL Server Express o SQLite
